package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SettingsBrightness
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppThemeMode
import com.example.data.model.CategoryEnum
import com.example.data.model.TweakItem
import com.example.ui.components.BatteryMetricCard
import com.example.ui.components.DeviceHeaderCard
import com.example.ui.components.RamMetricCard
import com.example.ui.components.StorageMetricCard
import com.example.ui.components.TweakCard
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.AccentRed
import com.example.ui.viewmodel.EverTweakUiState
import com.example.ui.viewmodel.EverTweakViewModel

@Composable
fun DashboardScreen(
    uiState: EverTweakUiState,
    viewModel: EverTweakViewModel,
    contentPadding: PaddingValues,
    modifier: Modifier = Modifier
) {
    val dashboardTweaks = uiState.tweakList.filter { it.category == CategoryEnum.DASHBOARD }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("dashboard_screen"),
        contentPadding = contentPadding,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Device header card
        item {
            DeviceHeaderCard(device = uiState.deviceDetails)
        }

        // System Write Permission Banner if not granted
        if (!uiState.canWriteSettings) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("permission_banner_card"),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = AccentAmber.copy(alpha = 0.15f)
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = AccentAmber,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "System Settings Permission",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Grant 'Modify system settings' to allow EverTweak Lite to adjust timeout and auto-rotate directly.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                val timeoutTweak = uiState.tweakList.find { it.id == "dash_screen_timeout" }
                                if (timeoutTweak != null) {
                                    viewModel.showExplanation(timeoutTweak)
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("grant_permission_btn")
                        ) {
                            Text("Grant", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Live Diagnostic Metrics Row
        item {
            Text(
                text = "Live Telemetry & Diagnostics",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(8.dp))
            BatteryMetricCard(battery = uiState.batteryInfo)
            Spacer(modifier = Modifier.height(12.dp))
            StorageMetricCard(storage = uiState.storageInfo)
            Spacer(modifier = Modifier.height(12.dp))
            RamMetricCard(memory = uiState.memoryInfo)
        }

        // Quick Tweaks section
        item {
            Text(
                text = "Quick Adjustments & Shortcuts",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        items(dashboardTweaks, key = { it.id }) { tweak ->
            TweakCard(
                tweak = tweak,
                isFavorite = uiState.userPreferences.favoriteIds.contains(tweak.id),
                onFavoriteToggle = { viewModel.toggleFavorite(tweak.id) },
                onClick = { viewModel.onTweakClicked(tweak) },
                onInfoClick = { viewModel.showExplanation(tweak) },
                onSelectorOptionSelected = { idx -> viewModel.onScreenTimeoutOptionSelected(idx) }
            )
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun CustomizationScreen(
    uiState: EverTweakUiState,
    viewModel: EverTweakViewModel,
    contentPadding: PaddingValues,
    onBackToHome: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBackToHome() }

    val customizationTweaks = uiState.tweakList.filter { it.category == CategoryEnum.CUSTOMIZATION }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("customization_screen"),
        contentPadding = contentPadding,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App Theme Customizer Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("theme_selector_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
                )
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.SettingsBrightness,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "EverTweak Theme & Contrast",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ThemeOptionChip(
                            label = "System",
                            icon = Icons.Default.Settings,
                            isSelected = uiState.userPreferences.themeMode == AppThemeMode.SYSTEM,
                            onClick = { viewModel.setThemeMode(AppThemeMode.SYSTEM) },
                            modifier = Modifier.weight(1f)
                        )
                        ThemeOptionChip(
                            label = "Light",
                            icon = Icons.Default.LightMode,
                            isSelected = uiState.userPreferences.themeMode == AppThemeMode.LIGHT,
                            onClick = { viewModel.setThemeMode(AppThemeMode.LIGHT) },
                            modifier = Modifier.weight(1f)
                        )
                        ThemeOptionChip(
                            label = "Dark",
                            icon = Icons.Default.DarkMode,
                            isSelected = uiState.userPreferences.themeMode == AppThemeMode.DARK,
                            onClick = { viewModel.setThemeMode(AppThemeMode.DARK) },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // AMOLED switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Pure Black AMOLED Mode",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Uses true #000000 background pixels on OLED screens for zero battery drain.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = uiState.userPreferences.amoledMode,
                            onCheckedChange = { viewModel.setAmoledMode(it) },
                            modifier = Modifier.testTag("amoled_switch")
                        )
                    }
                }
            }
        }

        // Customization Tweaks List
        items(customizationTweaks, key = { it.id }) { tweak ->
            TweakCard(
                tweak = tweak,
                isFavorite = uiState.userPreferences.favoriteIds.contains(tweak.id),
                onFavoriteToggle = { viewModel.toggleFavorite(tweak.id) },
                onClick = { viewModel.onTweakClicked(tweak) },
                onInfoClick = { viewModel.showExplanation(tweak) }
            )
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun ThemeOptionChip(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    FilterChip(
        selected = isSelected,
        onClick = onClick,
        leadingIcon = {
            Icon(
                imageVector = icon,
                contentDescription = null,
                modifier = Modifier.size(16.dp)
            )
        },
        label = {
            Text(
                text = label,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
            )
        },
        modifier = modifier
    )
}

@Composable
fun StatusBarScreen(
    uiState: EverTweakUiState,
    viewModel: EverTweakViewModel,
    contentPadding: PaddingValues,
    onBackToHome: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBackToHome() }

    val statusBarTweaks = uiState.tweakList.filter { it.category == CategoryEnum.STATUS_BAR }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("status_bar_screen"),
        contentPadding = contentPadding,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Quick Settings Tile How-to Hero Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("qs_guide_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
                )
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "EverTweak Tile Service is Active",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Android allows apps to provide custom Quick Settings tiles. You can add 'EverTweak Panel' to your notification shade for instant access anytime:\n\n" +
                                "1. Swipe down twice from the top of your screen to open Quick Settings.\n" +
                                "2. Tap the Pencil / Edit icon.\n" +
                                "3. Scroll to find 'EverTweak Panel' and drag it up into your active tiles.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }

        items(statusBarTweaks, key = { it.id }) { tweak ->
            TweakCard(
                tweak = tweak,
                isFavorite = uiState.userPreferences.favoriteIds.contains(tweak.id),
                onFavoriteToggle = { viewModel.toggleFavorite(tweak.id) },
                onClick = { viewModel.onTweakClicked(tweak) },
                onInfoClick = { viewModel.showExplanation(tweak) }
            )
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun PerformanceScreen(
    uiState: EverTweakUiState,
    viewModel: EverTweakViewModel,
    contentPadding: PaddingValues,
    onBackToHome: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBackToHome() }

    val perfTweaks = uiState.tweakList.filter { it.category == CategoryEnum.PERFORMANCE }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("performance_screen"),
        contentPadding = contentPadding,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Honesty & Truth Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("ram_truth_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f)
                )
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Genuine Optimization vs Placebos",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Unlike scam utilities, EverTweak Lite never claims to artificially 'boost CPU' or 'clear RAM'. " +
                                "Android's Linux kernel efficiently keeps apps cached in RAM to prevent battery-draining cold starts. " +
                                "Below are verified, battery-saving recommendations and official storage tools.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Tips List
        item {
            Text(
                text = "Android & One UI Battery Optimization Tips",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        item {
            TipCard(
                title = "1. Enable Adaptive Battery",
                description = "Lets Android learn your app usage routines and restrict apps you seldom use from draining background juice."
            )
        }

        item {
            TipCard(
                title = "2. Use Dark Mode on OLED/AMOLED",
                description = "Black pixels on OLED displays are physically turned off, reducing screen power draw by up to 30%."
            )
        }

        item {
            TipCard(
                title = "3. Check High Refresh Rate (120Hz)",
                description = "If you need maximum endurance on low battery, setting your screen to standard 60Hz can extend runtime by 1-2 hours."
            )
        }

        item {
            TipCard(
                title = "4. Clear Temporary App Cache, Not App Data",
                description = "Use Settings > Storage to remove stale downloaded cache without deleting your logins or account data."
            )
        }

        items(perfTweaks, key = { it.id }) { tweak ->
            TweakCard(
                tweak = tweak,
                isFavorite = uiState.userPreferences.favoriteIds.contains(tweak.id),
                onFavoriteToggle = { viewModel.toggleFavorite(tweak.id) },
                onClick = { viewModel.onTweakClicked(tweak) },
                onInfoClick = { viewModel.showExplanation(tweak) }
            )
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun TipCard(
    title: String,
    description: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun GesturesAndAdvancedScreen(
    uiState: EverTweakUiState,
    viewModel: EverTweakViewModel,
    contentPadding: PaddingValues,
    onBackToHome: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBackToHome() }

    val gestureTweaks = uiState.tweakList.filter { it.category == CategoryEnum.GESTURES }
    val shizukuTweaks = uiState.tweakList.filter { it.category == CategoryEnum.SHIZUKU }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("gestures_advanced_screen"),
        contentPadding = contentPadding,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Gestures Section
        item {
            Text(
                text = "System Gestures & Accessibility",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        items(gestureTweaks, key = { it.id }) { tweak ->
            TweakCard(
                tweak = tweak,
                isFavorite = uiState.userPreferences.favoriteIds.contains(tweak.id),
                onFavoriteToggle = { viewModel.toggleFavorite(tweak.id) },
                onClick = { viewModel.onTweakClicked(tweak) },
                onInfoClick = { viewModel.showExplanation(tweak) }
            )
        }

        // Shizuku Advanced Section
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Advanced Module: Shizuku (Disabled by Default)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.secondary
            )
        }

        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("shizuku_module_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f)
                )
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(MaterialTheme.colorScheme.secondaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Terminal,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Shizuku Wireless ADB",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (uiState.userPreferences.shizukuModuleEnabled) "Module Active" else "Disabled (Default)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (uiState.userPreferences.shizukuModuleEnabled) AccentGreen else MaterialTheme.colorScheme.outline
                                )
                            }
                        }

                        Switch(
                            checked = uiState.userPreferences.shizukuModuleEnabled,
                            onCheckedChange = { enabled ->
                                viewModel.requestShizukuToggle(enabled)
                            },
                            modifier = Modifier.testTag("shizuku_toggle_switch")
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Shizuku bridges apps with ADB privileges via Wireless Debugging without root. " +
                                "EverTweak Lite keeps this disabled by default to guarantee full privacy and safety for ordinary users.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        if (uiState.userPreferences.shizukuModuleEnabled) {
            items(shizukuTweaks, key = { it.id }) { tweak ->
                TweakCard(
                    tweak = tweak,
                    isFavorite = uiState.userPreferences.favoriteIds.contains(tweak.id),
                    onFavoriteToggle = { viewModel.toggleFavorite(tweak.id) },
                    onClick = { viewModel.onTweakClicked(tweak) },
                    onInfoClick = { viewModel.showExplanation(tweak) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
