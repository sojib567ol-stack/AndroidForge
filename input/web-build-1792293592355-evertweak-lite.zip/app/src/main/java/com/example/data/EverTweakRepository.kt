package com.example.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.AppThemeMode
import com.example.data.model.BatteryInfo
import com.example.data.model.CategoryEnum
import com.example.data.model.DeviceDetails
import com.example.data.model.MemoryInfoData
import com.example.data.model.StorageInfo
import com.example.data.model.TweakActionType
import com.example.data.model.TweakItem
import com.example.data.model.UserPreferences
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "evertweak_prefs")

class EverTweakRepository(private val context: Context) {

    private val inspector = SystemInspector(context)

    companion object {
        val KEY_THEME_MODE = stringPreferencesKey("theme_mode")
        val KEY_AMOLED_MODE = booleanPreferencesKey("amoled_mode")
        val KEY_FAVORITES = stringSetPreferencesKey("favorite_ids")
        val KEY_SHIZUKU_ENABLED = booleanPreferencesKey("shizuku_enabled")
        val KEY_SHIZUKU_DISCLOSURE = booleanPreferencesKey("shizuku_disclosure")
        val KEY_HAPTIC_STRENGTH = intPreferencesKey("haptic_strength")
    }

    val userPreferencesFlow: Flow<UserPreferences> = context.dataStore.data.map { prefs ->
        val themeStr = prefs[KEY_THEME_MODE] ?: AppThemeMode.SYSTEM.name
        val themeMode = try {
            AppThemeMode.valueOf(themeStr)
        } catch (e: Exception) {
            AppThemeMode.SYSTEM
        }
        val amoled = prefs[KEY_AMOLED_MODE] ?: false
        val favorites = prefs[KEY_FAVORITES] ?: emptySet()
        val shizukuEnabled = prefs[KEY_SHIZUKU_ENABLED] ?: false
        val shizukuDisclosure = prefs[KEY_SHIZUKU_DISCLOSURE] ?: false
        val haptic = prefs[KEY_HAPTIC_STRENGTH] ?: 1

        UserPreferences(
            themeMode = themeMode,
            amoledMode = amoled,
            favoriteIds = favorites,
            shizukuModuleEnabled = shizukuEnabled,
            shizukuDisclosureAccepted = shizukuDisclosure,
            hapticFeedbackStrength = haptic
        )
    }

    suspend fun setThemeMode(mode: AppThemeMode) {
        context.dataStore.edit { it[KEY_THEME_MODE] = mode.name }
    }

    suspend fun setAmoledMode(enabled: Boolean) {
        context.dataStore.edit { it[KEY_AMOLED_MODE] = enabled }
    }

    suspend fun toggleFavorite(tweakId: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[KEY_FAVORITES] ?: emptySet()
            if (current.contains(tweakId)) {
                prefs[KEY_FAVORITES] = current - tweakId
            } else {
                prefs[KEY_FAVORITES] = current + tweakId
            }
        }
    }

    suspend fun setShizukuEnabled(enabled: Boolean) {
        context.dataStore.edit { it[KEY_SHIZUKU_ENABLED] = enabled }
    }

    suspend fun setShizukuDisclosureAccepted(accepted: Boolean) {
        context.dataStore.edit { it[KEY_SHIZUKU_DISCLOSURE] = accepted }
    }

    suspend fun resetAllToDefaults(): Boolean {
        // Reset in-app preferences
        context.dataStore.edit { prefs ->
            prefs.clear()
        }
        // If write settings permitted, reset managed system tweaks to standard defaults (30s timeout, auto-rotate on)
        if (inspector.canWriteSystemSettings()) {
            inspector.setScreenTimeoutMs(30000)
            inspector.setAutoRotate(true)
        }
        return true
    }

    // Diagnostics
    fun getBatteryInfo(): BatteryInfo = inspector.getBatteryInfo()
    fun getStorageInfo(): StorageInfo = inspector.getStorageInfo()
    fun getMemoryInfo(): MemoryInfoData = inspector.getMemoryInfo()
    fun getDeviceDetails(): DeviceDetails = inspector.getDeviceDetails()
    fun canWriteSystemSettings(): Boolean = inspector.canWriteSystemSettings()
    fun isNotificationPolicyAccessGranted(): Boolean = inspector.isNotificationPolicyAccessGranted()
    fun isShizukuInstalled(): Boolean = inspector.isShizukuInstalled()

    // System changes
    fun setScreenTimeout(timeoutMs: Int): Boolean = inspector.setScreenTimeoutMs(timeoutMs)
    fun setAutoRotate(enabled: Boolean): Boolean = inspector.setAutoRotate(enabled)

    // Build tweak catalog
    fun getTweakCatalog(): List<TweakItem> {
        val canWrite = inspector.canWriteSystemSettings()
        val currentTimeout = inspector.getScreenTimeoutMs()
        val isAutoRotate = inspector.isAutoRotateEnabled()
        val animScale = inspector.getGlobalAnimationScale()
        val dndAccess = inspector.isNotificationPolicyAccessGranted()
        val isShizuku = inspector.isShizukuInstalled()
        val device = inspector.getDeviceDetails()

        val timeoutOptions = listOf("15 sec", "30 sec", "1 min", "2 min", "5 min", "10 min")
        val timeoutIndex = when (currentTimeout) {
            15000 -> 0
            30000 -> 1
            60000 -> 2
            120000 -> 3
            300000 -> 4
            600000 -> 5
            else -> 1
        }

        return listOf(
            // DASHBOARD TWEAKS
            TweakItem(
                id = "dash_screen_timeout",
                title = "Screen Timeout",
                description = "Adjust display inactivity sleep delay.",
                category = CategoryEnum.DASHBOARD,
                iconKey = "timer",
                tags = listOf("screen", "timeout", "display", "battery", "sleep"),
                actionType = TweakActionType.SELECTOR,
                isManagedByApp = true,
                requiresSpecialPermission = !canWrite,
                permissionExplanation = "Android requires 'Modify system settings' permission to alter screen timeout directly from this app. Tap below to grant permission.",
                settingsIntentAction = Settings.ACTION_MANAGE_WRITE_SETTINGS,
                currentValueText = timeoutOptions.getOrElse(timeoutIndex) { "${currentTimeout / 1000}s" },
                selectorOptions = timeoutOptions,
                selectedIndex = timeoutIndex
            ),
            TweakItem(
                id = "dash_auto_rotate",
                title = "Auto-Rotate Display",
                description = "Toggle screen orientation sensor lock.",
                category = CategoryEnum.DASHBOARD,
                iconKey = "screen_rotation",
                tags = listOf("rotate", "orientation", "sensor", "display"),
                actionType = TweakActionType.TOGGLE,
                isManagedByApp = true,
                requiresSpecialPermission = !canWrite,
                permissionExplanation = "Modifying display orientation lock requires 'Modify system settings' authorization on Android.",
                settingsIntentAction = Settings.ACTION_MANAGE_WRITE_SETTINGS,
                isEnabledOrChecked = isAutoRotate,
                currentValueText = if (isAutoRotate) "Enabled" else "Locked"
            ),
            TweakItem(
                id = "dash_sound_settings",
                title = "Sound & Vibration Settings",
                description = "Direct shortcut to system audio profiles, volume sliders, and vibration patterns.",
                category = CategoryEnum.DASHBOARD,
                iconKey = "volume_up",
                tags = listOf("sound", "volume", "vibration", "ringtone"),
                actionType = TweakActionType.LAUNCH_SETTING,
                settingsIntentAction = Settings.ACTION_SOUND_SETTINGS
            ),
            TweakItem(
                id = "dash_display_settings",
                title = "Display & Brightness Settings",
                description = "Open device display settings for color balance, adaptive brightness, and refresh rate.",
                category = CategoryEnum.DASHBOARD,
                iconKey = "brightness_medium",
                tags = listOf("brightness", "display", "refresh rate", "color"),
                actionType = TweakActionType.LAUNCH_SETTING,
                settingsIntentAction = Settings.ACTION_DISPLAY_SETTINGS
            ),

            // CUSTOMIZATION
            TweakItem(
                id = "cust_wallpaper",
                title = "Wallpaper & Lock Screen",
                description = "Launch system wallpaper picker and lock screen customization panel.",
                category = CategoryEnum.CUSTOMIZATION,
                iconKey = "wallpaper",
                tags = listOf("wallpaper", "background", "lock screen", "style"),
                actionType = TweakActionType.LAUNCH_SETTING,
                settingsIntentAction = Intent.ACTION_SET_WALLPAPER
            ),
            TweakItem(
                id = "cust_font_size",
                title = "Font & Display Size",
                description = "Adjust text scale, font family, and UI element density for optimal readability.",
                category = CategoryEnum.CUSTOMIZATION,
                iconKey = "format_size",
                tags = listOf("font", "text", "size", "density", "dpi"),
                actionType = TweakActionType.LAUNCH_SETTING,
                settingsIntentAction = Settings.ACTION_DISPLAY_SETTINGS
            ),
            TweakItem(
                id = "cust_animation_scale",
                title = "System Animation Scales",
                description = "Current system animation duration scale: ${animScale}x. Speeds up app transitions.",
                category = CategoryEnum.CUSTOMIZATION,
                iconKey = "speed",
                tags = listOf("animation", "speed", "transitions", "scale", "window"),
                actionType = TweakActionType.LAUNCH_SETTING,
                requiresSpecialPermission = true,
                permissionExplanation = "Android security strictly blocks regular apps from writing Global Animation Scale settings. Changing this requires Developer Options or ADB/Shizuku privileges.",
                settingsIntentAction = Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS,
                currentValueText = "${animScale}x Scale"
            ),
            TweakItem(
                id = "cust_night_light",
                title = "Night Light / Eye Comfort",
                description = "Warm screen colors to reduce blue light strain in low-light environments.",
                category = CategoryEnum.CUSTOMIZATION,
                iconKey = "nights_stay",
                tags = listOf("night light", "blue light", "eye comfort", "reading mode"),
                actionType = TweakActionType.LAUNCH_SETTING,
                settingsIntentAction = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    Settings.ACTION_NIGHT_DISPLAY_SETTINGS
                } else {
                    Settings.ACTION_DISPLAY_SETTINGS
                }
            ),
            TweakItem(
                id = "cust_high_contrast",
                title = "High Contrast Text & Color Correction",
                description = "Enhance text outlines and screen contrast for outdoor visibility.",
                category = CategoryEnum.CUSTOMIZATION,
                iconKey = "contrast",
                tags = listOf("contrast", "accessibility", "color inversion", "text"),
                actionType = TweakActionType.LAUNCH_SETTING,
                settingsIntentAction = Settings.ACTION_ACCESSIBILITY_SETTINGS
            ),

            // STATUS BAR & QUICK SETTINGS
            TweakItem(
                id = "qs_tile_helper",
                title = "EverTweak Quick Settings Tile",
                description = "Add our quick tile to your notification shade for 1-tap toolkit access.",
                category = CategoryEnum.STATUS_BAR,
                iconKey = "dashboard_customize",
                tags = listOf("tile", "quick settings", "status bar", "notification"),
                actionType = TweakActionType.INFO_ONLY,
                permissionExplanation = "Swipe down twice from top of screen -> Tap pencil/edit button -> Drag 'EverTweak Panel' into your active tiles."
            ),
            TweakItem(
                id = "qs_dnd_policy",
                title = "Do Not Disturb & Notification Rules",
                description = "Configure priority interruptions, quiet hours, and status bar notification alerts.",
                category = CategoryEnum.STATUS_BAR,
                iconKey = "do_not_disturb_on",
                tags = listOf("dnd", "do not disturb", "priority", "silent"),
                actionType = TweakActionType.LAUNCH_SETTING,
                requiresSpecialPermission = !dndAccess,
                permissionExplanation = "Android requires explicit Notification Policy Access to toggle Do Not Disturb modes.",
                settingsIntentAction = Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS,
                currentValueText = if (dndAccess) "Access Granted" else "Action Required"
            ),
            TweakItem(
                id = "qs_notification_channels",
                title = "App Notification Channels & Badges",
                description = "Fine-tune app icon badges, lock screen banners, and silent notifications.",
                category = CategoryEnum.STATUS_BAR,
                iconKey = "notifications",
                tags = listOf("notifications", "badges", "status bar", "channels"),
                actionType = TweakActionType.LAUNCH_SETTING,
                settingsIntentAction = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    Settings.ACTION_APP_NOTIFICATION_SETTINGS
                } else {
                    Settings.ACTION_SETTINGS
                }
            ),
            TweakItem(
                id = "qs_status_bar_restrictions",
                title = "Status Bar Privacy & System Limits",
                description = "Understand Android's strict boundary preventing apps from altering system icons.",
                category = CategoryEnum.STATUS_BAR,
                iconKey = "info",
                tags = listOf("status bar", "icons", "privacy", "battery icon", "clock"),
                actionType = TweakActionType.INFO_ONLY,
                permissionExplanation = "In Android 10+ and One UI, third-party apps cannot hide system status icons (battery, Wi-Fi, clock) without root or manufacturer system keys. EverTweak Lite respects your security and does not inject untrusted code."
            ),

            // PERFORMANCE & BATTERY TIPS
            TweakItem(
                id = "perf_storage_manager",
                title = "Internal Storage & App Cache",
                description = "Inspect space breakdown and clean temporary cached files safely.",
                category = CategoryEnum.PERFORMANCE,
                iconKey = "storage",
                tags = listOf("storage", "cache", "clean", "disk", "space"),
                actionType = TweakActionType.LAUNCH_SETTING,
                settingsIntentAction = Settings.ACTION_INTERNAL_STORAGE_SETTINGS
            ),
            TweakItem(
                id = "perf_battery_saver",
                title = "Battery Saver & Power Modes",
                description = "Access native battery saver, adaptive power, and background limits.",
                category = CategoryEnum.PERFORMANCE,
                iconKey = "battery_saver",
                tags = listOf("battery", "power save", "adaptive", "sleep apps"),
                actionType = TweakActionType.LAUNCH_SETTING,
                settingsIntentAction = Settings.ACTION_BATTERY_SAVER_SETTINGS
            ),
            TweakItem(
                id = "perf_ram_truth",
                title = "RAM Truth & Task Killer Warning",
                description = "Why Android RAM optimization differs from desktop computers.",
                category = CategoryEnum.PERFORMANCE,
                iconKey = "memory",
                tags = listOf("ram", "memory", "task killer", "boost", "performance"),
                actionType = TweakActionType.INFO_ONLY,
                permissionExplanation = "Modern Android uses Linux virtual memory. Free RAM is wasted RAM — Android caches apps in background memory so they open instantaneously. Third-party 'RAM Cleaners' force apps to quit, causing excessive CPU spikes and battery drain when they relaunch."
            ),
            TweakItem(
                id = "perf_battery_optimization",
                title = "Battery Optimization Whitelist",
                description = "Prevent aggressive OEM battery managers from killing essential background tasks.",
                category = CategoryEnum.PERFORMANCE,
                iconKey = "electric_bolt",
                tags = listOf("doze", "whitelist", "background", "killing apps", "samsung one ui"),
                actionType = TweakActionType.LAUNCH_SETTING,
                settingsIntentAction = Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS
            ),

            // GESTURES & ACCESSIBILITY
            TweakItem(
                id = "gest_system_navigation",
                title = "System Navigation (Gestures / 3-Button)",
                description = "Switch between full screen swipe gestures and the classic 3-button navigation bar.",
                category = CategoryEnum.GESTURES,
                iconKey = "navigation",
                tags = listOf("gestures", "navigation", "buttons", "swipe", "back gesture"),
                actionType = TweakActionType.LAUNCH_SETTING,
                settingsIntentAction = if (device.isSamsungOneUI) {
                    Settings.ACTION_DISPLAY_SETTINGS
                } else {
                    Settings.ACTION_SETTINGS
                }
            ),
            TweakItem(
                id = "gest_one_handed",
                title = "One-Handed Mode",
                description = "Pull down on bottom edge of screen to reach top items with one thumb.",
                category = CategoryEnum.GESTURES,
                iconKey = "front_hand",
                tags = listOf("one handed", "reachability", "thumb", "gestures"),
                actionType = TweakActionType.LAUNCH_SETTING,
                settingsIntentAction = Settings.ACTION_ACCESSIBILITY_SETTINGS
            ),
            TweakItem(
                id = "gest_accessibility_menu",
                title = "Accessibility Assistant Menu",
                description = "Large on-screen floating menu for volume, power off, screenshot, and notification pull-down.",
                category = CategoryEnum.GESTURES,
                iconKey = "accessibility_new",
                tags = listOf("accessibility", "assistant", "shortcut", "menu"),
                actionType = TweakActionType.LAUNCH_SETTING,
                settingsIntentAction = Settings.ACTION_ACCESSIBILITY_SETTINGS
            ),
            TweakItem(
                id = "gest_safety_statement",
                title = "Safe Accessibility Policy",
                description = "Why EverTweak Lite never requests Accessibility Service permissions.",
                category = CategoryEnum.GESTURES,
                iconKey = "security",
                tags = listOf("security", "accessibility service", "privacy", "no root"),
                actionType = TweakActionType.INFO_ONLY,
                permissionExplanation = "Android Accessibility Services grant complete screen-reading access. Many untrusted customization apps abuse this permission to log keystrokes or draw overlays. EverTweak Lite strictly uses official system intents and never inspects your screen."
            ),

            // ADVANCED SHIZUKU
            TweakItem(
                id = "shizuku_status",
                title = "Shizuku Service Status",
                description = if (isShizuku) "Shizuku Manager is installed on this device." else "Shizuku Manager app was not detected.",
                category = CategoryEnum.SHIZUKU,
                iconKey = "terminal",
                tags = listOf("shizuku", "adb", "wireless debugging", "rootless"),
                actionType = TweakActionType.SHIZUKU_ACTION,
                currentValueText = if (isShizuku) "Installed" else "Not Detected"
            ),
            TweakItem(
                id = "shizuku_wireless_debugging",
                title = "Developer Options & Wireless Debugging",
                description = "Shortcut to Developer Options required to start Shizuku without a PC.",
                category = CategoryEnum.SHIZUKU,
                iconKey = "developer_mode",
                tags = listOf("developer options", "adb", "wireless debugging", "pairing"),
                actionType = TweakActionType.LAUNCH_SETTING,
                settingsIntentAction = Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS
            )
        )
    }

    fun launchSettingIntent(action: String?): Boolean {
        if (action.isNullOrBlank()) return false
        return try {
            val intent = when (action) {
                Settings.ACTION_MANAGE_WRITE_SETTINGS -> {
                    Intent(action).apply {
                        data = Uri.parse("package:${context.packageName}")
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                }
                Intent.ACTION_SET_WALLPAPER -> {
                    Intent(Intent.ACTION_SET_WALLPAPER).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Settings.ACTION_APP_NOTIFICATION_SETTINGS else "android.settings.APP_NOTIFICATION_SETTINGS" -> {
                    Intent(action).apply {
                        putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                }
                else -> {
                    Intent(action).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                }
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            // Fallback to standard settings
            try {
                val fallbackIntent = Intent(Settings.ACTION_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(fallbackIntent)
                true
            } catch (ignored: Exception) {
                false
            }
        }
    }
}
