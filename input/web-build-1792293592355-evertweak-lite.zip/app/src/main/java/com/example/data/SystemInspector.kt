package com.example.data

import android.app.ActivityManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.WindowManager
import com.example.data.model.BatteryInfo
import com.example.data.model.DeviceDetails
import com.example.data.model.MemoryInfoData
import com.example.data.model.StorageInfo
import java.io.File

class SystemInspector(private val context: Context) {

    fun getBatteryInfo(): BatteryInfo {
        return try {
            val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val intent = context.registerReceiver(null, filter)
            val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: 100
            val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: 100
            val percent = if (level >= 0 && scale > 0) (level * 100) / scale else 100

            val statusInt = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val isCharging = statusInt == BatteryManager.BATTERY_STATUS_CHARGING ||
                    statusInt == BatteryManager.BATTERY_STATUS_FULL
            val status = when (statusInt) {
                BatteryManager.BATTERY_STATUS_CHARGING -> "Charging"
                BatteryManager.BATTERY_STATUS_FULL -> "Full"
                BatteryManager.BATTERY_STATUS_DISCHARGING -> "Discharging"
                BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Not Charging"
                else -> "Discharging"
            }

            val healthInt = intent?.getIntExtra(BatteryManager.EXTRA_HEALTH, -1) ?: -1
            val health = when (healthInt) {
                BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
                BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheating"
                BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"
                BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over Voltage"
                BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Failure"
                BatteryManager.BATTERY_HEALTH_COLD -> "Cold"
                else -> "Good"
            }

            val tempTenths = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 250) ?: 250
            val tempC = tempTenths / 10f
            val voltage = intent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 4000) ?: 4000
            val tech = intent?.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: "Li-ion"

            val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            val isPowerSave = powerManager?.isPowerSaveMode ?: false

            BatteryInfo(
                level = percent,
                isCharging = isCharging,
                status = status,
                health = health,
                temperatureC = tempC,
                voltageMv = voltage,
                technology = tech,
                powerSaveMode = isPowerSave
            )
        } catch (e: Exception) {
            BatteryInfo()
        }
    }

    fun getStorageInfo(): StorageInfo {
        return try {
            val dataDir: File = Environment.getDataDirectory()
            val statFs = StatFs(dataDir.path)
            val blockSize = statFs.blockSizeLong
            val totalBlocks = statFs.blockCountLong
            val availableBlocks = statFs.availableBlocksLong

            val totalBytes = totalBlocks * blockSize
            val freeBytes = availableBlocks * blockSize
            val usedBytes = (totalBytes - freeBytes).coerceAtLeast(0L)
            val usedPercent = if (totalBytes > 0) ((usedBytes * 100) / totalBytes).toInt() else 0

            StorageInfo(
                totalBytes = totalBytes,
                usedBytes = usedBytes,
                freeBytes = freeBytes,
                usedPercent = usedPercent
            )
        } catch (e: Exception) {
            StorageInfo()
        }
    }

    fun getMemoryInfo(): MemoryInfoData {
        return try {
            val actManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val memInfo = ActivityManager.MemoryInfo()
            actManager.getMemoryInfo(memInfo)

            val totalBytes = memInfo.totalMem
            val availBytes = memInfo.availMem
            val usedBytes = (totalBytes - availBytes).coerceAtLeast(0L)

            MemoryInfoData(
                totalRamBytes = totalBytes,
                availRamBytes = availBytes,
                usedRamBytes = usedBytes,
                isLowMemory = memInfo.lowMemory
            )
        } catch (e: Exception) {
            MemoryInfoData()
        }
    }

    fun getDeviceDetails(): DeviceDetails {
        val manufacturer = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
        val model = Build.MODEL
        val deviceCodename = Build.DEVICE
        val androidVersion = Build.VERSION.RELEASE
        val sdkInt = Build.VERSION.SDK_INT
        val securityPatch = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Build.VERSION.SECURITY_PATCH
        } else {
            "N/A"
        }
        val buildDisplay = Build.DISPLAY

        var isSamsung = manufacturer.equals("Samsung", ignoreCase = true)
        var oneUIVer = ""
        if (isSamsung) {
            try {
                val clazz = Class.forName("android.os.SystemProperties")
                val getMethod = clazz.getMethod("get", String::class.java)
                val ver = getMethod.invoke(null, "ro.build.version.oneui") as? String
                if (!ver.isNullOrBlank()) {
                    val verInt = ver.toIntOrNull()
                    oneUIVer = if (verInt != null && verInt > 10000) {
                        "${verInt / 10000}.${(verInt % 10000) / 100}"
                    } else {
                        ver
                    }
                } else {
                    oneUIVer = "One UI (Supported)"
                }
            } catch (ignored: Exception) {
                oneUIVer = "One UI"
            }
        }

        var refreshRate = 60f
        var resolution = "1080 x 2400"
        try {
            val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
            if (wm != null) {
                val display = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    context.display
                } else {
                    @Suppress("DEPRECATION")
                    wm.defaultDisplay
                }
                if (display != null) {
                    refreshRate = display.refreshRate
                    val metrics = DisplayMetrics()
                    @Suppress("DEPRECATION")
                    display.getRealMetrics(metrics)
                    resolution = "${metrics.widthPixels} x ${metrics.heightPixels}"
                }
            }
        } catch (ignored: Exception) {}

        return DeviceDetails(
            manufacturer = manufacturer,
            model = model,
            deviceCodename = deviceCodename,
            androidVersion = "Android $androidVersion",
            sdkInt = sdkInt,
            securityPatch = securityPatch,
            buildNumber = buildDisplay,
            displayRefreshRate = refreshRate,
            screenResolution = resolution,
            isSamsungOneUI = isSamsung,
            oneUIVersion = oneUIVer
        )
    }

    fun canWriteSystemSettings(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.System.canWrite(context)
        } else {
            true
        }
    }

    fun isNotificationPolicyAccessGranted(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            nm?.isNotificationPolicyAccessGranted ?: false
        } else {
            true
        }
    }

    fun getScreenTimeoutMs(): Int {
        return try {
            Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_OFF_TIMEOUT, 30000)
        } catch (e: Exception) {
            30000
        }
    }

    fun setScreenTimeoutMs(timeoutMs: Int): Boolean {
        if (!canWriteSystemSettings()) return false
        return try {
            Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_OFF_TIMEOUT, timeoutMs)
        } catch (e: Exception) {
            false
        }
    }

    fun isAutoRotateEnabled(): Boolean {
        return try {
            Settings.System.getInt(context.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0) == 1
        } catch (e: Exception) {
            false
        }
    }

    fun setAutoRotate(enabled: Boolean): Boolean {
        if (!canWriteSystemSettings()) return false
        return try {
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.ACCELEROMETER_ROTATION,
                if (enabled) 1 else 0
            )
        } catch (e: Exception) {
            false
        }
    }

    fun getGlobalAnimationScale(): Float {
        return try {
            Settings.Global.getFloat(context.contentResolver, Settings.Global.WINDOW_ANIMATION_SCALE, 1.0f)
        } catch (e: Exception) {
            1.0f
        }
    }

    fun isShizukuInstalled(): Boolean {
        return try {
            context.packageManager.getPackageInfo("moe.shizuku.privileged.api", 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        } catch (e: Exception) {
            false
        }
    }
}
