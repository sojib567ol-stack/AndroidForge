package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppThemeMode
import com.example.data.model.CategoryEnum
import com.example.ui.components.ExplanationDialog
import com.example.ui.components.ResetDefaultsDialog
import com.example.ui.components.ShizukuDisclosureDialog
import com.example.ui.components.TweakCard
import com.example.ui.screens.CustomizationScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.GesturesAndAdvancedScreen
import com.example.ui.screens.PerformanceScreen
import com.example.ui.screens.StatusBarScreen
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentRed
import com.example.ui.theme.EverTweakTheme
import com.example.ui.viewmodel.EverTweakViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: EverTweakViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()
            val context = LocalContext.current

            // Determine dark theme
            val isDarkTheme = when (uiState.userPreferences.themeMode) {
                AppThemeMode.DARK -> true
                AppThemeMode.LIGHT -> false
                AppThemeMode.SYSTEM -> isSystemInDarkTheme()
            }

            EverTweakTheme(
                darkTheme = isDarkTheme,
                amoledMode = uiState.userPreferences.amoledMode
            ) {
                val snackbarHostState = remember { SnackbarHostState() }
                var currentTab by remember { mutableIntStateOf(0) }
                var isSearchActive by remember { mutableStateOf(false) }

                // Toast message handling
                LaunchedEffect(uiState.toastMessage) {
                    uiState.toastMessage?.let { msg ->
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                        viewModel.clearToastMessage()
                    }
                }

                // Global BackHandler when searching
                if (isSearchActive || uiState.searchQuery.isNotEmpty()) {
                    BackHandler {
                        isSearchActive = false
                        viewModel.setSearchQuery("")
                    }
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    topBar = {
                        Column {
                            TopAppBar(
                                title = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(34.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(MaterialTheme.colorScheme.primary),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Tune,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.onPrimary,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = "EverTweak Lite",
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = "Safe Customization Toolkit",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    }
                                },
                                actions = {
                                    // Search toggle
                                    IconButton(
                                        onClick = { isSearchActive = !isSearchActive },
                                        modifier = Modifier.testTag("top_search_btn")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Search,
                                            contentDescription = "Search tweaks",
                                            tint = if (isSearchActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                        )
                                    }

                                    // Favorites filter toggle
                                    IconButton(
                                        onClick = { viewModel.toggleShowOnlyFavorites() },
                                        modifier = Modifier.testTag("top_fav_filter_btn")
                                    ) {
                                        Icon(
                                            imageVector = if (uiState.showOnlyFavorites) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                            contentDescription = "Show favorites only",
                                            tint = if (uiState.showOnlyFavorites) AccentRed else MaterialTheme.colorScheme.onSurface
                                        )
                                    }

                                    // Reset to defaults
                                    IconButton(
                                        onClick = { viewModel.requestResetDefaultsDialog() },
                                        modifier = Modifier.testTag("top_reset_btn")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.RestartAlt,
                                            contentDescription = "Reset managed tweaks to defaults",
                                            tint = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                },
                                colors = TopAppBarDefaults.topAppBarColors(
                                    containerColor = MaterialTheme.colorScheme.surface
                                )
                            )

                            // Search bar when active
                            AnimatedVisibility(
                                visible = isSearchActive || uiState.searchQuery.isNotEmpty(),
                                enter = fadeIn(),
                                exit = fadeOut()
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 6.dp)
                                ) {
                                    OutlinedTextField(
                                        value = uiState.searchQuery,
                                        onValueChange = { viewModel.setSearchQuery(it) },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("search_text_field"),
                                        placeholder = { Text("Search tweaks, battery, gestures, display...") },
                                        singleLine = true,
                                        leadingIcon = {
                                            Icon(Icons.Default.Search, contentDescription = null)
                                        },
                                        trailingIcon = {
                                            if (uiState.searchQuery.isNotEmpty()) {
                                                IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                                    Icon(Icons.Default.Clear, contentDescription = "Clear search")
                                                }
                                            }
                                        },
                                        shape = RoundedCornerShape(16.dp),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                                            unfocusedBorderColor = MaterialTheme.colorScheme.outline
                                        )
                                    )
                                }
                            }

                            // Category filter chips
                            LazyRow(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 4.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(CategoryEnum.values()) { category ->
                                    val isSelected = uiState.selectedCategory == category
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = {
                                            viewModel.setCategory(category)
                                            // Sync tab if clicking a category
                                            when (category) {
                                                CategoryEnum.DASHBOARD -> currentTab = 0
                                                CategoryEnum.CUSTOMIZATION -> currentTab = 1
                                                CategoryEnum.STATUS_BAR -> currentTab = 2
                                                CategoryEnum.PERFORMANCE -> currentTab = 3
                                                CategoryEnum.GESTURES, CategoryEnum.SHIZUKU -> currentTab = 4
                                                else -> {}
                                            }
                                        },
                                        label = {
                                            Text(
                                                text = category.displayName,
                                                fontSize = 12.sp,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                            )
                                        },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                        )
                                    )
                                }
                            }
                        }
                    },
                    bottomBar = {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface,
                            tonalElevation = 6.dp
                        ) {
                            NavigationBarItem(
                                selected = currentTab == 0 && uiState.searchQuery.isEmpty(),
                                onClick = {
                                    currentTab = 0
                                    viewModel.setCategory(CategoryEnum.DASHBOARD)
                                },
                                icon = { Icon(Icons.Default.Dashboard, contentDescription = "Dashboard") },
                                label = { Text("Dashboard", fontSize = 11.sp) },
                                modifier = Modifier.testTag("nav_tab_dashboard")
                            )

                            NavigationBarItem(
                                selected = currentTab == 1 && uiState.searchQuery.isEmpty(),
                                onClick = {
                                    currentTab = 1
                                    viewModel.setCategory(CategoryEnum.CUSTOMIZATION)
                                },
                                icon = { Icon(Icons.Default.Palette, contentDescription = "Customization") },
                                label = { Text("Customize", fontSize = 11.sp) },
                                modifier = Modifier.testTag("nav_tab_customize")
                            )

                            NavigationBarItem(
                                selected = currentTab == 2 && uiState.searchQuery.isEmpty(),
                                onClick = {
                                    currentTab = 2
                                    viewModel.setCategory(CategoryEnum.STATUS_BAR)
                                },
                                icon = { Icon(Icons.Default.Tune, contentDescription = "Status Bar and Quick Settings") },
                                label = { Text("Status & QS", fontSize = 11.sp) },
                                modifier = Modifier.testTag("nav_tab_status_bar")
                            )

                            NavigationBarItem(
                                selected = currentTab == 3 && uiState.searchQuery.isEmpty(),
                                onClick = {
                                    currentTab = 3
                                    viewModel.setCategory(CategoryEnum.PERFORMANCE)
                                },
                                icon = { Icon(Icons.Default.Speed, contentDescription = "Performance and Battery") },
                                label = { Text("Performance", fontSize = 11.sp) },
                                modifier = Modifier.testTag("nav_tab_performance")
                            )

                            NavigationBarItem(
                                selected = currentTab == 4 && uiState.searchQuery.isEmpty(),
                                onClick = {
                                    currentTab = 4
                                    viewModel.setCategory(CategoryEnum.GESTURES)
                                },
                                icon = { Icon(Icons.Default.Widgets, contentDescription = "Gestures & Advanced") },
                                label = { Text("Advanced", fontSize = 11.sp) },
                                modifier = Modifier.testTag("nav_tab_advanced")
                            )
                        }
                    }
                ) { innerPadding ->
                    // If searching or category is ALL, show unified search results list
                    if (uiState.searchQuery.isNotEmpty() || (uiState.selectedCategory == CategoryEnum.ALL && currentTab != 0)) {
                        SearchResultsList(
                            uiState = uiState,
                            viewModel = viewModel,
                            contentPadding = innerPadding,
                            onBackToHome = {
                                currentTab = 0
                                viewModel.setCategory(CategoryEnum.DASHBOARD)
                                viewModel.setSearchQuery("")
                            }
                        )
                    } else {
                        when (currentTab) {
                            0 -> DashboardScreen(
                                uiState = uiState,
                                viewModel = viewModel,
                                contentPadding = PaddingValues(
                                    start = 16.dp,
                                    end = 16.dp,
                                    top = innerPadding.calculateTopPadding() + 8.dp,
                                    bottom = innerPadding.calculateBottomPadding() + 16.dp
                                )
                            )
                            1 -> CustomizationScreen(
                                uiState = uiState,
                                viewModel = viewModel,
                                contentPadding = PaddingValues(
                                    start = 16.dp,
                                    end = 16.dp,
                                    top = innerPadding.calculateTopPadding() + 8.dp,
                                    bottom = innerPadding.calculateBottomPadding() + 16.dp
                                ),
                                onBackToHome = {
                                    currentTab = 0
                                    viewModel.setCategory(CategoryEnum.DASHBOARD)
                                }
                            )
                            2 -> StatusBarScreen(
                                uiState = uiState,
                                viewModel = viewModel,
                                contentPadding = PaddingValues(
                                    start = 16.dp,
                                    end = 16.dp,
                                    top = innerPadding.calculateTopPadding() + 8.dp,
                                    bottom = innerPadding.calculateBottomPadding() + 16.dp
                                ),
                                onBackToHome = {
                                    currentTab = 0
                                    viewModel.setCategory(CategoryEnum.DASHBOARD)
                                }
                            )
                            3 -> PerformanceScreen(
                                uiState = uiState,
                                viewModel = viewModel,
                                contentPadding = PaddingValues(
                                    start = 16.dp,
                                    end = 16.dp,
                                    top = innerPadding.calculateTopPadding() + 8.dp,
                                    bottom = innerPadding.calculateBottomPadding() + 16.dp
                                ),
                                onBackToHome = {
                                    currentTab = 0
                                    viewModel.setCategory(CategoryEnum.DASHBOARD)
                                }
                            )
                            4 -> GesturesAndAdvancedScreen(
                                uiState = uiState,
                                viewModel = viewModel,
                                contentPadding = PaddingValues(
                                    start = 16.dp,
                                    end = 16.dp,
                                    top = innerPadding.calculateTopPadding() + 8.dp,
                                    bottom = innerPadding.calculateBottomPadding() + 16.dp
                                ),
                                onBackToHome = {
                                    currentTab = 0
                                    viewModel.setCategory(CategoryEnum.DASHBOARD)
                                }
                            )
                        }
                    }
                }

                // Dialogs
                uiState.activeExplanationDialog?.let { tweak ->
                    ExplanationDialog(
                        tweak = tweak,
                        onDismiss = { viewModel.dismissExplanation() },
                        onOpenSettings = { viewModel.openSettingsForActiveDialog() }
                    )
                }

                if (uiState.showResetDefaultsDialog) {
                    ResetDefaultsDialog(
                        onDismiss = { viewModel.dismissResetDefaultsDialog() },
                        onConfirm = { viewModel.confirmResetDefaults() }
                    )
                }

                if (uiState.showShizukuDisclosureDialog) {
                    ShizukuDisclosureDialog(
                        onDismiss = { viewModel.cancelShizukuDisclosure() },
                        onConfirm = { viewModel.confirmShizukuDisclosure() }
                    )
                }
            }
        }
    }
}

@Composable
fun SearchResultsList(
    uiState: com.example.ui.viewmodel.EverTweakUiState,
    viewModel: EverTweakViewModel,
    contentPadding: PaddingValues,
    onBackToHome: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBackToHome() }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("search_results_list"),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = contentPadding.calculateTopPadding() + 8.dp,
            bottom = contentPadding.calculateBottomPadding() + 16.dp
        ),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = if (uiState.searchQuery.isNotEmpty()) {
                    "Search Results (${uiState.tweakList.size})"
                } else if (uiState.showOnlyFavorites) {
                    "Favorite Tweaks (${uiState.tweakList.size})"
                } else {
                    "All Available Tweaks (${uiState.tweakList.size})"
                },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        if (uiState.tweakList.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No matching tweaks or settings found.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            items(uiState.tweakList, key = { it.id }) { tweak ->
                TweakCard(
                    tweak = tweak,
                    isFavorite = uiState.userPreferences.favoriteIds.contains(tweak.id),
                    onFavoriteToggle = { viewModel.toggleFavorite(tweak.id) },
                    onClick = { viewModel.onTweakClicked(tweak) },
                    onInfoClick = { viewModel.showExplanation(tweak) },
                    onSelectorOptionSelected = { idx -> viewModel.onScreenTimeoutOptionSelected(idx) }
                )
            }
        }
    }
}
