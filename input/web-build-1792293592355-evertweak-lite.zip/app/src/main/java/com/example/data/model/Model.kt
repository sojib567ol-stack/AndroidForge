package com.example.data.model

enum class CategoryEnum(val displayName: String) {
    ALL("All Tweaks"),
    DASHBOARD("Dashboard"),
    CUSTOMIZATION("Customization"),
    STATUS_BAR("Status Bar & QS"),
    PERFORMANCE("Performance & Battery"),
    GESTURES("Gestures & Access"),
    SHIZUKU("Shizuku (Advanced)")
}

enum class TweakActionType {
    TOGGLE,
    LAUNCH_SETTING,
    SELECTOR,
    TEST_FEEDBACK,
    INFO_ONLY,
    SHIZUKU_ACTION
}

data class TweakItem(
    val id: String,
    val title: String,
    val description: String,
    val category: CategoryEnum,
    val iconKey: String,
    val tags: List<String>,
    val actionType: TweakActionType,
    val isManagedByApp: Boolean = false,
    val requiresSpecialPermission: Boolean = false,
    val permissionExplanation: String = "",
    val settingsIntentAction: String? = null,
    val systemSettingKey: String? = null,
    val currentValueText: String = "",
    val isEnabledOrChecked: Boolean = false,
    val selectorOptions: List<String> = emptyList(),
    val selectedIndex: Int = 0
)

data class BatteryInfo(
    val level: Int = 100,
    val isCharging: Boolean = false,
    val status: String = "Normal",
    val health: String = "Good",
    val temperatureC: Float = 25f,
    val voltageMv: Int = 4000,
    val technology: String = "Li-ion",
    val powerSaveMode: Boolean = false
)

data class StorageInfo(
    val totalBytes: Long = 0L,
    val usedBytes: Long = 0L,
    val freeBytes: Long = 0L,
    val usedPercent: Int = 0
)

data class MemoryInfoData(
    val totalRamBytes: Long = 0L,
    val availRamBytes: Long = 0L,
    val usedRamBytes: Long = 0L,
    val isLowMemory: Boolean = false
)

data class DeviceDetails(
    val manufacturer: String = "",
    val model: String = "",
    val deviceCodename: String = "",
    val androidVersion: String = "",
    val sdkInt: Int = 0,
    val securityPatch: String = "",
    val buildNumber: String = "",
    val displayRefreshRate: Float = 60f,
    val screenResolution: String = "",
    val isSamsungOneUI: Boolean = false,
    val oneUIVersion: String = ""
)

enum class AppThemeMode {
    SYSTEM,
    LIGHT,
    DARK
}

data class UserPreferences(
    val themeMode: AppThemeMode = AppThemeMode.SYSTEM,
    val amoledMode: Boolean = false,
    val favoriteIds: Set<String> = emptySet(),
    val shizukuModuleEnabled: Boolean = false,
    val shizukuDisclosureAccepted: Boolean = false,
    val simulatedAnimationSpeedOverride: Float = 1.0f,
    val hapticFeedbackStrength: Int = 1 // 0=Off, 1=Normal, 2=Strong
)
