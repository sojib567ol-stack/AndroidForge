package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Scheme Colors
val PrimaryLight = Color(0xFF006A60)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFF73F8E6)
val OnPrimaryContainerLight = Color(0xFF00201C)

val SecondaryLight = Color(0xFF2A628F)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFCCE5FF)
val OnSecondaryContainerLight = Color(0xFF001D33)

val TertiaryLight = Color(0xFF8B5000)
val OnTertiaryLight = Color(0xFFFFFFFF)
val TertiaryContainerLight = Color(0xFFFFDDB8)
val OnTertiaryContainerLight = Color(0xFF2C1600)

val BackgroundLight = Color(0xFFF6F9FD)
val OnBackgroundLight = Color(0xFF191C1E)
val SurfaceLight = Color(0xFFFFFFFF)
val OnSurfaceLight = Color(0xFF191C1E)
val SurfaceVariantLight = Color(0xFFDAE5E3)
val OnSurfaceVariantLight = Color(0xFF3F4947)
val OutlineLight = Color(0xFF6F7977)

// Dark Scheme Colors (High-Tech Customization aesthetic)
val PrimaryDark = Color(0xFF4EE3D0)
val OnPrimaryDark = Color(0xFF003731)
val PrimaryContainerDark = Color(0xFF005048)
val OnPrimaryContainerDark = Color(0xFF73F8E6)

val SecondaryDark = Color(0xFF82B1FF)
val OnSecondaryDark = Color(0xFF002F65)
val SecondaryContainerDark = Color(0xFF163E75)
val OnSecondaryContainerDark = Color(0xFFD6E3FF)

val TertiaryDark = Color(0xFFFFB866)
val OnTertiaryDark = Color(0xFF4A2800)
val TertiaryContainerDark = Color(0xFF693C00)
val OnTertiaryContainerDark = Color(0xFFFFDDB8)

val BackgroundDark = Color(0xFF0C1322)
val OnBackgroundDark = Color(0xFFE2E8F0)
val SurfaceDark = Color(0xFF151F36)
val OnSurfaceDark = Color(0xFFE2E8F0)
val SurfaceVariantDark = Color(0xFF233252)
val OnSurfaceVariantDark = Color(0xFFB0BFD8)
val OutlineDark = Color(0xFF475B7D)

// Special accents
val AccentCyan = Color(0xFF00E5FF)
val AccentGreen = Color(0xFF10B981)
val AccentAmber = Color(0xFFF59E0B)
val AccentRed = Color(0xFFEF4444)
val AccentPurple = Color(0xFFA855F7)
val AmoledBackground = Color(0xFF000000)
val AmoledSurface = Color(0xFF0E0E10)
