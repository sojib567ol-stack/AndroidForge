package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.EverTweakRepository
import com.example.data.model.AppThemeMode
import com.example.data.model.BatteryInfo
import com.example.data.model.CategoryEnum
import com.example.data.model.DeviceDetails
import com.example.data.model.MemoryInfoData
import com.example.data.model.StorageInfo
import com.example.data.model.TweakActionType
import com.example.data.model.TweakItem
import com.example.data.model.UserPreferences
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class EverTweakUiState(
    val batteryInfo: BatteryInfo = BatteryInfo(),
    val storageInfo: StorageInfo = StorageInfo(),
    val memoryInfo: MemoryInfoData = MemoryInfoData(),
    val deviceDetails: DeviceDetails = DeviceDetails(),
    val selectedCategory: CategoryEnum = CategoryEnum.ALL,
    val searchQuery: String = "",
    val showOnlyFavorites: Boolean = false,
    val canWriteSettings: Boolean = false,
    val userPreferences: UserPreferences = UserPreferences(),
    val tweakList: List<TweakItem> = emptyList(),
    val activeExplanationDialog: TweakItem? = null,
    val showResetDefaultsDialog: Boolean = false,
    val showShizukuDisclosureDialog: Boolean = false,
    val toastMessage: String? = null
)

class EverTweakViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = EverTweakRepository(application.applicationContext)

    private val _uiState = MutableStateFlow(EverTweakUiState())
    val uiState: StateFlow<EverTweakUiState> = _uiState.asStateFlow()

    init {
        // Collect preferences
        viewModelScope.launch {
            repository.userPreferencesFlow.collect { prefs ->
                _uiState.update { current ->
                    current.copy(
                        userPreferences = prefs
                    )
                }
                reloadTweaks()
            }
        }

        // Periodic diagnostic telemetry refresh
        viewModelScope.launch {
            while (true) {
                refreshDiagnostics()
                delay(4000)
            }
        }
    }

    fun refreshDiagnostics() {
        val battery = repository.getBatteryInfo()
        val storage = repository.getStorageInfo()
        val memory = repository.getMemoryInfo()
        val device = repository.getDeviceDetails()
        val canWrite = repository.canWriteSystemSettings()

        _uiState.update { current ->
            current.copy(
                batteryInfo = battery,
                storageInfo = storage,
                memoryInfo = memory,
                deviceDetails = device,
                canWriteSettings = canWrite
            )
        }
        reloadTweaks()
    }

    fun reloadTweaks() {
        val rawList = repository.getTweakCatalog()
        val favorites = _uiState.value.userPreferences.favoriteIds
        val query = _uiState.value.searchQuery.trim().lowercase()
        val category = _uiState.value.selectedCategory
        val onlyFavorites = _uiState.value.showOnlyFavorites

        val filtered = rawList.filter { tweak ->
            // Category check
            val matchesCategory = if (category == CategoryEnum.ALL) true else tweak.category == category
            // Favorites check
            val matchesFavorites = if (onlyFavorites) favorites.contains(tweak.id) else true
            // Search query check
            val matchesQuery = if (query.isEmpty()) {
                true
            } else {
                tweak.title.lowercase().contains(query) ||
                        tweak.description.lowercase().contains(query) ||
                        tweak.tags.any { it.lowercase().contains(query) }
            }
            matchesCategory && matchesFavorites && matchesQuery
        }

        _uiState.update { it.copy(tweakList = filtered) }
    }

    fun setCategory(category: CategoryEnum) {
        _uiState.update { it.copy(selectedCategory = category) }
        reloadTweaks()
    }

    fun setSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
        reloadTweaks()
    }

    fun toggleShowOnlyFavorites() {
        _uiState.update { it.copy(showOnlyFavorites = !it.showOnlyFavorites) }
        reloadTweaks()
    }

    fun toggleFavorite(tweakId: String) {
        viewModelScope.launch {
            repository.toggleFavorite(tweakId)
        }
    }

    fun onTweakClicked(tweak: TweakItem) {
        when (tweak.actionType) {
            TweakActionType.LAUNCH_SETTING -> {
                if (tweak.requiresSpecialPermission && !tweak.permissionExplanation.isNullOrBlank()) {
                    showExplanation(tweak)
                } else {
                    val launched = repository.launchSettingIntent(tweak.settingsIntentAction)
                    if (!launched) {
                        _uiState.update { it.copy(toastMessage = "Could not open settings on this device.") }
                    }
                }
            }
            TweakActionType.TOGGLE -> {
                if (tweak.id == "dash_auto_rotate") {
                    if (!repository.canWriteSystemSettings()) {
                        showExplanation(tweak)
                    } else {
                        val newState = !tweak.isEnabledOrChecked
                        val success = repository.setAutoRotate(newState)
                        if (success) {
                            _uiState.update { it.copy(toastMessage = if (newState) "Auto-rotate enabled" else "Orientation locked") }
                            refreshDiagnostics()
                        } else {
                            showExplanation(tweak)
                        }
                    }
                }
            }
            TweakActionType.SELECTOR -> {
                if (tweak.id == "dash_screen_timeout") {
                    if (!repository.canWriteSystemSettings()) {
                        showExplanation(tweak)
                    }
                }
            }
            TweakActionType.INFO_ONLY -> {
                showExplanation(tweak)
            }
            TweakActionType.SHIZUKU_ACTION -> {
                if (!_uiState.value.userPreferences.shizukuModuleEnabled) {
                    _uiState.update { it.copy(showShizukuDisclosureDialog = true) }
                } else {
                    showExplanation(tweak)
                }
            }
            else -> {}
        }
    }

    fun onScreenTimeoutOptionSelected(index: Int) {
        val msValues = listOf(15000, 30000, 60000, 120000, 300000, 600000)
        val selectedMs = msValues.getOrElse(index) { 30000 }
        if (!repository.canWriteSystemSettings()) {
            val timeoutTweak = repository.getTweakCatalog().find { it.id == "dash_screen_timeout" }
            if (timeoutTweak != null) {
                showExplanation(timeoutTweak)
            }
            return
        }
        val success = repository.setScreenTimeout(selectedMs)
        if (success) {
            _uiState.update { it.copy(toastMessage = "Screen timeout set to ${_uiState.value.tweakList.find { it.id == "dash_screen_timeout" }?.selectorOptions?.getOrNull(index) ?: "new value"}") }
            refreshDiagnostics()
        } else {
            _uiState.update { it.copy(toastMessage = "Failed to modify screen timeout.") }
        }
    }

    fun showExplanation(tweak: TweakItem) {
        _uiState.update { it.copy(activeExplanationDialog = tweak) }
    }

    fun dismissExplanation() {
        _uiState.update { it.copy(activeExplanationDialog = null) }
    }

    fun openSettingsForActiveDialog() {
        val tweak = _uiState.value.activeExplanationDialog
        dismissExplanation()
        if (tweak != null) {
            val launched = repository.launchSettingIntent(tweak.settingsIntentAction)
            if (!launched) {
                _uiState.update { it.copy(toastMessage = "Unable to open system settings page.") }
            }
        }
    }

    fun setThemeMode(mode: AppThemeMode) {
        viewModelScope.launch {
            repository.setThemeMode(mode)
        }
    }

    fun setAmoledMode(enabled: Boolean) {
        viewModelScope.launch {
            repository.setAmoledMode(enabled)
        }
    }

    fun requestShizukuToggle(enabled: Boolean) {
        if (enabled && !_uiState.value.userPreferences.shizukuDisclosureAccepted) {
            _uiState.update { it.copy(showShizukuDisclosureDialog = true) }
        } else {
            viewModelScope.launch {
                repository.setShizukuEnabled(enabled)
                _uiState.update { it.copy(toastMessage = if (enabled) "Shizuku module enabled" else "Shizuku module disabled") }
            }
        }
    }

    fun confirmShizukuDisclosure() {
        viewModelScope.launch {
            repository.setShizukuDisclosureAccepted(true)
            repository.setShizukuEnabled(true)
            _uiState.update {
                it.copy(
                    showShizukuDisclosureDialog = false,
                    toastMessage = "Shizuku advanced module enabled safely."
                )
            }
        }
    }

    fun cancelShizukuDisclosure() {
        _uiState.update { it.copy(showShizukuDisclosureDialog = false) }
    }

    fun requestResetDefaultsDialog() {
        _uiState.update { it.copy(showResetDefaultsDialog = true) }
    }

    fun dismissResetDefaultsDialog() {
        _uiState.update { it.copy(showResetDefaultsDialog = false) }
    }

    fun confirmResetDefaults() {
        viewModelScope.launch {
            repository.resetAllToDefaults()
            _uiState.update {
                it.copy(
                    showResetDefaultsDialog = false,
                    toastMessage = "All managed tweaks restored to original Android defaults."
                )
            }
            refreshDiagnostics()
        }
    }

    fun clearToastMessage() {
        _uiState.update { it.copy(toastMessage = null) }
    }
}
