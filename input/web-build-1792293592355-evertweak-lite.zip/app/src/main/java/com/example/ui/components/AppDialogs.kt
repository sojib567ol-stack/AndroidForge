package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.TweakItem
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.AccentRed

@Composable
fun ExplanationDialog(
    tweak: TweakItem,
    onDismiss: () -> Unit,
    onOpenSettings: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        if (tweak.requiresSpecialPermission) AccentAmber.copy(alpha = 0.2f)
                        else MaterialTheme.colorScheme.primaryContainer
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (tweak.requiresSpecialPermission) Icons.Default.Warning else Icons.Default.Info,
                    contentDescription = null,
                    tint = if (tweak.requiresSpecialPermission) AccentAmber else MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(28.dp)
                )
            }
        },
        title = {
            Text(
                text = tweak.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column {
                Text(
                    text = if (tweak.permissionExplanation.isNotBlank()) {
                        tweak.permissionExplanation
                    } else {
                        tweak.description
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                if (tweak.requiresSpecialPermission) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Safety Note: EverTweak Lite never uses root exploits or hidden private APIs. When Android protects a setting, we direct you to the official system interface.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        },
        confirmButton = {
            if (!tweak.settingsIntentAction.isNullOrBlank()) {
                Button(
                    onClick = onOpenSettings,
                    modifier = Modifier.testTag("dialog_open_settings_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.OpenInNew,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Open Settings")
                }
            } else {
                Button(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("dialog_close_btn")
                ) {
                    Text("Understood")
                }
            }
        },
        dismissButton = {
            if (!tweak.settingsIntentAction.isNullOrBlank()) {
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("dialog_cancel_btn")
                ) {
                    Text("Close")
                }
            }
        }
    )
}

@Composable
fun ResetDefaultsDialog(
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(AccentRed.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.RestartAlt,
                    contentDescription = null,
                    tint = AccentRed,
                    modifier = Modifier.size(28.dp)
                )
            }
        },
        title = {
            Text(
                text = "Reset Managed Tweaks?",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column {
                Text(
                    text = "This will revert settings managed by EverTweak Lite back to factory defaults:\n" +
                            "• Screen Timeout reverted to 30 seconds\n" +
                            "• Auto-Rotate display restored to enabled\n" +
                            "• App Theme reset to System Default\n" +
                            "• Saved favorites and Shizuku module cleared\n\n" +
                            "No user personal data or system files will be harmed.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = AccentRed),
                modifier = Modifier.testTag("confirm_reset_btn")
            ) {
                Text("Reset to Defaults", color = MaterialTheme.colorScheme.surface)
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_reset_btn")
            ) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun ShizukuDisclosureDialog(
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(28.dp)
                )
            }
        },
        title = {
            Text(
                text = "Enable Advanced Shizuku Module?",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column {
                Text(
                    text = "Shizuku is an open-source bridge that allows user-granted apps to run ADB-level operations safely without rooting the device.\n\n" +
                            "What this enables in EverTweak Lite:\n" +
                            "• Inspect package states and developer options safely.\n" +
                            "• Read secure system settings.\n\n" +
                            "Security Guarantees:\n" +
                            "• EverTweak Lite will NEVER execute destructive commands or root exploits.\n" +
                            "• You can disable this module at any time.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                modifier = Modifier.testTag("enable_shizuku_btn")
            ) {
                Text("Enable Module")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_shizuku_btn")
            ) {
                Text("Cancel")
            }
        }
    )
}
