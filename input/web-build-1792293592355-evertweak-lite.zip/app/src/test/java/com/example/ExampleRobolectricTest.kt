package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.EverTweakRepository
import com.example.data.SystemInspector
import com.example.data.model.CategoryEnum
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun testAppNameResource() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("EverTweak Lite", appName)
  }

  @Test
  fun testSystemInspectorTelemetry() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val inspector = SystemInspector(context)

    val battery = inspector.getBatteryInfo()
    assertNotNull(battery)
    assertTrue(battery.level >= 0)

    val storage = inspector.getStorageInfo()
    assertNotNull(storage)

    val memory = inspector.getMemoryInfo()
    assertNotNull(memory)

    val device = inspector.getDeviceDetails()
    assertNotNull(device)
    assertTrue(device.manufacturer.isNotBlank())
  }

  @Test
  fun testTweakCatalogIntegrity() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repo = EverTweakRepository(context)
    val catalog = repo.getTweakCatalog()

    assertTrue("Tweak catalog must contain tweaks across multiple categories", catalog.size >= 10)
    assertTrue(catalog.any { it.category == CategoryEnum.DASHBOARD })
    assertTrue(catalog.any { it.category == CategoryEnum.CUSTOMIZATION })
    assertTrue(catalog.any { it.category == CategoryEnum.STATUS_BAR })
    assertTrue(catalog.any { it.category == CategoryEnum.PERFORMANCE })
    assertTrue(catalog.any { it.category == CategoryEnum.GESTURES })
    assertTrue(catalog.any { it.category == CategoryEnum.SHIZUKU })
  }
}
